using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;

namespace VisionTech.GenieSMS
{
	/// <summary>
	/// Send SMS messages using Genie (www.genie.co.uk).
	/// </summary>
	/// <remarks>Genie allows you to send up to 600 SMS messages per month using a Genie account. This class
	/// connects to the Genie server using you login details to send an SMS message.</remarks>
	public class GenieSMS
	{
		/// <summary>
		/// Send an SMS message.
		/// </summary>
		/// <param name="username">Genie account username.</param>
		/// <param name="password">Genie account password.</param>
		/// <param name="number">Mobile phone number to send to (e.g. "07xxxxxxxxx" - replace x's with digits).</param>
		/// <param name="subject">Message subject.</param>
		/// <param name="message">Message body.</param>
		/// <remarks>Genie allows you to send a maximum of 115 characters. It starts the body on the
		/// line below the subject, so if you use the subject field, the total allowed is 114 characters
		/// (one less for the newline character).</remarks>
		public static void Send(string username,string password,string number,string subject,string message) {
			// SMS via Genie has restricted length
			if((subject.Length==0 && message.Length>115) || (subject.Length+message.Length>114)) throw new ArgumentException("Too many characters in subject/message");

			// Get cookie collection from logging in
			CookieContainer cc = Login(username,password);

			// Send SMS request
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://sendsms.genie.co.uk/cgi-bin/sms/send_sms.cgi");
			req.ContentType = "application/x-www-form-urlencoded";
			req.AllowAutoRedirect = false;
			req.KeepAlive = false;
			req.Method = "POST";
			req.CookieContainer = cc;
			StreamWriter wr = new StreamWriter(req.GetRequestStream(),Encoding.UTF8);
			string s = "contact=&RECIPIENT=" + EscapeString(number) + "&SUBJECT=" + EscapeString(subject) + "&MESSAGE=" + EscapeString(message) + "&action=Send&check=0&noOfPhones=";
			Debug.WriteLine(s);
			wr.Write(s);
			wr.Flush();
			wr.Close();
			HttpWebResponse resp = (HttpWebResponse)req.GetResponse();

			string body = new StreamReader(resp.GetResponseStream()).ReadToEnd();
			if(body.IndexOf("The text messaging facility is temporarily unavailable.")>=0) throw new ApplicationException("The text messaging facility is temporarily unavailable.");
		}

		/// <summary>
		/// Get cookie collection to use to send SMS message by logging in to the Genie site.
		/// </summary>
		/// <param name="username">Genie account username.</param>
		/// <param name="password">Genie account password.</param>
		/// <returns>A CookieContainer object to be used for the send request.</returns>
		private static CookieContainer Login(string username,string password) {
			CookieContainer cc = new CookieContainer();
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://www.genie.co.uk/login/doLogin");
			req.ContentType = "application/x-www-form-urlencoded";
			req.AllowAutoRedirect = false;
			req.KeepAlive = false;
			req.Method = "POST";
			req.CookieContainer = cc;
			StreamWriter wr = new StreamWriter(req.GetRequestStream(),Encoding.UTF8);
			string s = "dest=http%3A%2F%2Fsendsms.genie.co.uk%2Fcgi-bin%2Fsms%2Fsend_sms.cgi&numTries=&username=" + EscapeString(username) + "&password=" + EscapeString(password);
			Debug.WriteLine(s);
			wr.Write(s);
			wr.Flush();
			wr.Close();
			HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
			return cc;
		}

		private static string EscapeString(string s) {
			return System.Web.HttpUtility.UrlEncode(s,Encoding.Default);
		}
	}
}