// VTDskIco.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DesktopView.h"

static void SaveIcons(FILE* out)
{
	CDesktopView dv;
	POINT p;
	TCHAR name[MAX_PATH+1];

	if(dv.Open()) {
		for(DWORD i=0,j=dv.ItemCount(); i<j; i++) {
			if(dv.GetItemData(i,name,&p)) {
				USES_CONVERSION;
				fprintf(out,"%d,%d,%s\n",p.x,p.y,T2A(name));
			}
		}
		dv.Close();
	}
}

static void LoadIcons(FILE* in)
{
	CDesktopView dv;
	POINT p;
	char name[MAX_PATH+1];

	if(dv.Open()) {
		while(!feof(in)) {
			USES_CONVERSION;
			fscanf(in,"%d,%d,%[^\n]",&p.x,&p.y,name);
			dv.SetItemData(A2T(name),&p);
		}
		dv.Close();
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	if(argc==2) {
		if(!_tcscmp(argv[1],_T("-save"))) {
			SaveIcons(stdout); return 0;
		} else if(!_tcscmp(argv[1],_T("-load"))) {
			LoadIcons(stdin); return 0;
		}
	}
	fprintf(stderr,"Usage: VTDskIco [-load|-save]");
	return 0;
}