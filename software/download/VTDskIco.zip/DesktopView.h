/////////////////////////////////////////////////////////////////////////////
//
// Desktop Icon Positions
// (C) Copyright 2002 VisionTech Limited. All rights reserved.
// http://www.visiontech.ltd.uk/
// bateman@acm.org
//
// VisionTech Limited makes no warranties, either express or implied,
// with respect to this source code and any accompanying materials.
//
// In no event shall VisionTech Limited or its suppliers be liable for
// any damages whatsoever (including, without limitation, damages for
// loss of business profits, business interruption, loss of business
// information, or other percuniary loss) arising out of the use or
// inability to use this software.
//
// This source code may be used for any purpose, including commercial
// applications, and may be modified or redistributed subject to the
// following conditions:
//
// a) This notice may not be removed or changed in any source distribution.
//
// b) Altered source versions must include a note to that effect,
//    and must not be misrepresented as the original.
//
// c) The origin of this software may not be misrepresented - you may
//    not claim to have written the original version. If you use this
//    source in a product, an acknowledgement in the documentation
//    would be appreciated, but is not required.
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#define MAX(a,b)	(((a)>(b))?(a):(b))

class CDesktopView
{
public:

	CDesktopView(void) {
		m_hFolderViewWnd = FindFolderView();
		m_hFolderViewProc = NULL;
		m_lpProcData = NULL;
	}

	~CDesktopView(void) {
		Close();
	}

	bool Open() {
		// Open window owning process so that we can access its memory space
		const DWORD dwAccess = PROCESS_VM_OPERATION|PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_QUERY_INFORMATION;
		m_hFolderViewProc = OpenProcessFromWindow(m_hFolderViewWnd,dwAccess);
		if(m_hFolderViewProc==NULL) return false;

		// Allocate working space for windows message processing
		const DWORD dwSize = MAX(sizeof(LVITEM),sizeof(LVFINDINFO)) + (MAX_PATH + 1)*sizeof(TCHAR);
		if((m_lpProcData = VirtualAllocEx(m_hFolderViewProc,NULL,dwSize,MEM_COMMIT,PAGE_READWRITE))==NULL) {
			CloseHandle(m_hFolderViewProc);
			m_hFolderViewProc = NULL;
			return false;
		}
		return true;
	}

	void Close() {
		// Free memory and close process
		if(m_hFolderViewProc!=NULL) {
			if(m_lpProcData!=NULL) {
				VirtualFreeEx(m_hFolderViewProc,m_lpProcData,0,MEM_RELEASE);
				m_lpProcData = NULL;
			}
			CloseHandle(m_hFolderViewProc);
			m_hFolderViewProc = NULL;
		}
	}

	DWORD ItemCount() {
		return (DWORD)SendMessage(m_hFolderViewWnd,LVM_GETITEMCOUNT,0,0);
	}

	bool GetItemData(DWORD nItem,LPTSTR pszName,LPPOINT pPnt) {
		if(SendMessage(m_hFolderViewWnd,LVM_GETITEMPOSITION,nItem,(LPARAM)m_lpProcData)==FALSE) return false;
		if(ReadProcessMemory(m_hFolderViewProc,m_lpProcData,pPnt,sizeof(POINT),NULL)==0) return false;

		LVITEM lvi;
		ZeroMemory(&lvi,sizeof(lvi));
		lvi.mask = LVIF_TEXT;
		lvi.iItem = nItem;
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(((LPBYTE)m_lpProcData) + sizeof(lvi));
		lvi.cchTextMax = MAX_PATH+1;

		if(WriteProcessMemory(m_hFolderViewProc,m_lpProcData,&lvi,sizeof(lvi),NULL)==0) return false;
		DWORD nCnt = (DWORD)SendMessage(m_hFolderViewWnd,LVM_GETITEMTEXT,nItem,(LPARAM)m_lpProcData);
		if(nCnt==0) {
			*pszName = '\0';
		} else {
			if(ReadProcessMemory(m_hFolderViewProc,((LPBYTE)m_lpProcData) + sizeof(lvi),pszName,nCnt+1,NULL)==0) return false;
		}
		return true;
	}

	bool SetItemData(LPCTSTR pszName,const LPPOINT pPnt) {
		LVFINDINFO lfi;
		ZeroMemory(&lfi,sizeof(lfi));
		lfi.flags = LVFI_STRING;
		lfi.psz = (LPCTSTR)(((LPBYTE)m_lpProcData) + sizeof(lfi));
		if(WriteProcessMemory(m_hFolderViewProc,m_lpProcData,&lfi,sizeof(lfi),NULL)==0) return false;
		if(WriteProcessMemory(m_hFolderViewProc,(LPVOID)lfi.psz,pszName,_tcslen(pszName)+sizeof(TCHAR),NULL)==0) return false;
		int nItem = (int)SendMessage(m_hFolderViewWnd,LVM_FINDITEM,(WPARAM)(int)-1,(LPARAM)m_lpProcData);
		if(nItem<0) return true; // not found

		if(SendMessage(m_hFolderViewWnd,LVM_SETITEMPOSITION,nItem,MAKELPARAM(pPnt->x,pPnt->y))==FALSE) return false;
		return true;
	}


private:
	// Find Windows Desktop ListView control
	static HWND FindFolderView() {
		HWND hProgMan = FindWindow(_T("Progman"),NULL);
		if(hProgMan==NULL) return NULL;
		HWND hShellDef = FindWindowEx(hProgMan,NULL,_T("SHELLDLL_DefView"),NULL);
		if(hShellDef==NULL) return NULL;
		return FindWindowEx(hShellDef,NULL,NULL,_T("FolderView"));
	}

	// Open process that owns given window
	static HANDLE OpenProcessFromWindow(HWND hWnd,DWORD dwDesiredAccess) {
		DWORD dwProcessId;
		GetWindowThreadProcessId(hWnd,&dwProcessId);
		return OpenProcess(dwDesiredAccess,FALSE,dwProcessId);
	}

private:
	HWND	m_hFolderViewWnd;
	HANDLE	m_hFolderViewProc;
	LPVOID	m_lpProcData;
};

#undef MAX