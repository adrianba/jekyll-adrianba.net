using System;
using System.Xml.Serialization;

[CustomConfigHandler("myConfig",Group="sampleConfig")]
public class MyConfig : BaseConfigHandler
{
	[XmlAttribute("myString")]
	public string MyString;

	[XmlAttribute("myInt")]
	public int MyInt;

	public static MyConfig Current {
		get { return (MyConfig)GetCurrent(typeof(MyConfig)); }
	}
}