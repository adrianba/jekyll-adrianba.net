using System;

class App {
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main(string[] args) {
		DisplayInfo();
		DisplayInfo();
	}

	public static void DisplayInfo() {
		MyConfig config = MyConfig.Current;
		Console.WriteLine("Info: \"{0}\" {1}",config.MyString,config.MyInt);
	}
}