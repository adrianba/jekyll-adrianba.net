#pragma once


// NTLMFilt.h - Header file for your Internet Information Server
//    NTLM Auth Filter

#include "resource.h"

class CNTLMFilter : public CHttpFilter
{
public:
	CNTLMFilter();
	~CNTLMFilter();

// Overrides
	public:
	virtual BOOL GetFilterVersion(PHTTP_FILTER_VERSION pVer);
	virtual DWORD OnPreprocHeaders(CHttpFilterContext* pCtxt, PHTTP_FILTER_PREPROC_HEADERS pHeaderInfo);
	virtual DWORD OnEndOfNetSession(CHttpFilterContext* pCtxt);

private:
	typedef struct tagAuthData {
		CredHandle hCredential;
		CtxtHandle hContext;
		BOOL bAuthenticated;
	} AuthData;
};
