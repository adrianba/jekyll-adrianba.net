// NTLMFilt.cpp - Implementation file for ISAPI
//    NTLM Auth Filter

#include "stdafx.h"
#include "NTLMFilt.h"


// The one and only CWinApp object
// NOTE: You may remove this object if you alter your project to no
// longer use MFC in a DLL.

CWinApp theApp;




// The one and only CNTLMFilter object

CNTLMFilter theFilter;



// CNTLMFilter implementation

CNTLMFilter::CNTLMFilter()
{
}

CNTLMFilter::~CNTLMFilter()
{
}

BOOL CNTLMFilter::GetFilterVersion(PHTTP_FILTER_VERSION pVer)
{
	// Call default implementation for initialization
	CHttpFilter::GetFilterVersion(pVer);

	// Clear the flags set by base class
	pVer->dwFlags &= ~SF_NOTIFY_ORDER_MASK;

	// Set the flags we are interested in
	pVer->dwFlags |= SF_NOTIFY_SECURE_PORT | SF_NOTIFY_NONSECURE_PORT | SF_NOTIFY_PREPROC_HEADERS | SF_NOTIFY_END_OF_NET_SESSION;

	// Set Priority
	pVer->dwFlags |= SF_NOTIFY_ORDER_LOW;

	// Load description string
	TCHAR sz[SF_MAX_FILTER_DESC_LEN+1];
	ISAPIVERIFY(::LoadString(AfxGetResourceHandle(),
			IDS_FILTER, sz, SF_MAX_FILTER_DESC_LEN));
	_tcscpy(pVer->lpszFilterDesc, sz);
	return TRUE;
}

int base64encode(LPBYTE pOut,LPBYTE pIn,int dwLen);
int base64decode(LPBYTE pOut,LPBYTE pIn,int dwLen);

DWORD CNTLMFilter::OnPreprocHeaders(CHttpFilterContext* pCtxt,
	PHTTP_FILTER_PREPROC_HEADERS pHeaderInfo)
{
	static const LPCTSTR str401Denied = _T("401 Access Denied");

	TRACE("Processing headers\n");
	AuthData* pData;
	if((pData = (AuthData*)pCtxt->m_pFC->pFilterContext)==NULL) {
		pData = (AuthData*)pCtxt->AllocMem(sizeof(AuthData));
		SecInvalidateHandle(&pData->hCredential);
		SecInvalidateHandle(&pData->hContext);
		pData->bAuthenticated = FALSE;
		pCtxt->m_pFC->pFilterContext = pData;
	} else if(pData->bAuthenticated) {
		TRACE("Preauthenticated request\n");
		return SF_STATUS_REQ_NEXT_NOTIFICATION; // we're on an already authenticated connection
	}

	char auth[512];
	DWORD dwLen = 512;
	if(!pHeaderInfo->GetHeader(pCtxt->m_pFC,"Authorization:",auth,&dwLen)) {
		TRACE("No authorization so request NTLM\n");
		pCtxt->AddResponseHeaders("WWW-Authenticate: NTLM\r\n");
		pCtxt->ServerSupportFunction(SF_REQ_SEND_RESPONSE_HEADER,(LPVOID)str401Denied,NULL,NULL);
		return SF_STATUS_REQ_FINISHED;
	}

	if(strnicmp(auth,"NTLM ",5)) {
		TRACE("Expected NTLM but not present\n");
		// not sending NTLM authorization signal
		pCtxt->ServerSupportFunction(SF_REQ_SEND_RESPONSE_HEADER,(LPVOID)str401Denied,NULL,NULL);
		return SF_STATUS_REQ_FINISHED;
	}

	TimeStamp ts;
	if(!SecIsValidHandle(&pData->hCredential)) {
		if(AcquireCredentialsHandle(NULL,"NTLM",SECPKG_CRED_INBOUND,NULL,NULL,NULL,NULL,&pData->hCredential,&ts)!=SEC_E_OK) {
			TRACE("Failed to get NTLM credentials handle\n");
			pCtxt->ServerSupportFunction(SF_REQ_SEND_RESPONSE_HEADER,"500 AcquireCredentialsHandle failed",NULL,NULL);
			return SF_STATUS_REQ_FINISHED;
		}
		TRACE("Got credentials handle\n");
	}

	BYTE outbuf[256];
	dwLen = lstrlen(auth+5);
	TRACE(auth);
	int len = Base64DecodeGetRequiredLength(dwLen);
	LPBYTE inbuf = (LPBYTE)_alloca(len);
	if(!Base64Decode(auth+5,dwLen,inbuf,&len)) {
		TRACE("Base64 decode error\n");
		SetLastError(ERROR_INVALID_PARAMETER);
		return SF_STATUS_REQ_ERROR;
	}
	dwLen = len;

    SecBuffer sbi = {dwLen, SECBUFFER_TOKEN, inbuf};
    SecBuffer sbo = {256, SECBUFFER_TOKEN, outbuf};
    SecBufferDesc sbdi = {SECBUFFER_VERSION, 1, &sbi};
    SecBufferDesc sbdo = {SECBUFFER_VERSION, 1, &sbo};

	PCtxtHandle phContext = SecIsValidHandle(&pData->hContext) ? &pData->hContext : NULL;
	ULONG attr;
	SECURITY_STATUS ss = AcceptSecurityContext(&pData->hCredential,phContext,&sbdi,ASC_REQ_INTEGRITY,SECURITY_NETWORK_DREP,&pData->hContext,&sbdo,&attr,&ts);

	if(SEC_E_OK==ss) {
		TRACE("Handshake complete\n");
		pData->bAuthenticated = TRUE;
		HANDLE hToken;
		if(QuerySecurityContextToken(&pData->hContext,&hToken)==SEC_E_OK) {
			//TODO: lookup user name from token
			pHeaderInfo->AddHeader(pCtxt->m_pFC,"X-RemoteUser:","Fred");
			CloseHandle(hToken);
		}
	} else if(SEC_I_CONTINUE_NEEDED==ss) {
		TRACE("Need to continue NTLM handshake (%d)\n",sbo.cbBuffer);
		dwLen = Base64EncodeGetRequiredLength(sbo.cbBuffer);
		LPSTR encbuf = (LPSTR)_alloca(dwLen);
		if(!Base64Encode(outbuf,sbo.cbBuffer,encbuf,(int*)&dwLen,ATL_BASE64_FLAG_NOCRLF)) {
			TRACE("Base64Encode error\n");
			SetLastError(ERROR_INVALID_PARAMETER);
			return SF_STATUS_REQ_ERROR;
		}
		encbuf[dwLen] = '\0';
		dwLen = (DWORD)_tcslen(str401Denied);
		wsprintf(auth,"Content-Length: %d\r\nWWW-Authenticate: NTLM %s\r\n",dwLen,encbuf);
		TRACE(auth);
		pCtxt->AddResponseHeaders(auth);
		pCtxt->ServerSupportFunction(SF_REQ_SEND_RESPONSE_HEADER,(LPVOID)str401Denied,NULL,NULL);
		pCtxt->WriteClient((LPVOID)str401Denied,&dwLen);
		return SF_STATUS_REQ_FINISHED_KEEP_CONN;
	} else {
		TRACE("NTLM permission denied\n");
		pCtxt->ServerSupportFunction(SF_REQ_SEND_RESPONSE_HEADER,(LPVOID)str401Denied,NULL,NULL);
		return SF_STATUS_REQ_FINISHED;
	}

	return SF_STATUS_REQ_NEXT_NOTIFICATION;
}

DWORD CNTLMFilter::OnEndOfNetSession(CHttpFilterContext* pCtxt)
{
	AuthData* pData;
	if((pData = (AuthData*)pCtxt->m_pFC->pFilterContext)!=NULL) {
		if(SecIsValidHandle(&pData->hContext)) {
			TRACE("Tearing down context\n");
			DeleteSecurityContext(&pData->hContext);
			SecInvalidateHandle(&pData->hContext);
		}
		if(SecIsValidHandle(&pData->hCredential)) {
			TRACE("Tearing down credentials\n");
			FreeCredentialsHandle(&pData->hCredential);
			SecInvalidateHandle(&pData->hCredential);
		}
	}

	return SF_STATUS_REQ_NEXT_NOTIFICATION;
}

// If your extension will not use MFC, you'll need this code to make
// sure the extension objects can find the resource handle for the
// module.  If you convert your extension to not be dependent on MFC,
// remove the comments around the following AfxGetResourceHandle()
// and DllMain() functions, as well as the g_hInstance global.

/****

static HINSTANCE g_hInstance;

HINSTANCE AFXISAPI AfxGetResourceHandle()
{
	return g_hInstance;
}

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason,
					LPVOID lpReserved)
{
	if (ulReason == DLL_PROCESS_ATTACH)
	{
		g_hInstance = hInst;
	}

	return TRUE;
}

****/
