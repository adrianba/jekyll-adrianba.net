#define STRICT
#include <windows.h>

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR    lpCmdLine,
                     int       nCmdShow)
{
 	ShellExecute(GetDesktopWindow(),NULL,lpCmdLine,NULL,NULL,nCmdShow);
	return 0;
}
