/////////////////////////////////////////////////////////////////////////////
//
// Html Tidy .NET Binding
// (C) Copyright 2003 VisionTech Limited. All rights reserved.
// http://www.visiontech.ltd.uk/
// bateman@acm.org
//
// VisionTech Limited makes no warranties, either express or implied,
// with respect to this source code and any accompanying materials.
//
// In no event shall VisionTech Limited or its suppliers be liable for
// any damages whatsoever (including, without limitation, damages for
// loss of business profits, business interruption, loss of business
// information, or other percuniary loss) arising out of the use or
// inability to use this software.
//
// This source code may be used for any purpose, including commercial
// applications, and may be modified or redistributed subject to the
// following conditions:
//
// a) This notice may not be removed or changed in any source distribution.
//
// b) Altered source versions must include a note to that effect,
//    and must not be misrepresented as the original.
//
// c) The origin of this software may not be misrepresented - you may
//    not claim to have written the original version. If you use this
//    source in a product, an acknowledgement in the documentation
//    would be appreciated, but is not required.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TidyNET.h"

namespace VisionTech { namespace HtmlTidy {

Document::Document()
{
	TidyMem::Init();
	m_disposed = false;
	m_tdoc = tidyCreate();
	m_errbuf = new TidyBuffer;
	memset(m_errbuf,0,sizeof(TidyBuffer));
	tidySetErrorBuffer(m_tdoc,m_errbuf);
}

Document::~Document()
{
	Dispose();
}

void Document::Dispose()
{
	CheckDisposed();
	m_disposed = true;
	tidyBufFree(m_errbuf);
	tidyRelease(m_tdoc);
	delete m_errbuf;
	GC::SuppressFinalize(this);
}


String* Document::GetOptionString(OptionId id)
{
	CheckDisposed();
	ctmbstr s = tidyOptGetValue(m_tdoc,(TidyOptionId)id);
	return s!=NULL ? new String(s) : NULL;
}

bool Document::CopyOptions(Document* copyFrom)
{
	CheckDisposed();
	if(copyFrom==NULL) throw new ArgumentNullException(S"copyFrom");
	if(copyFrom->m_disposed) throw new ObjectDisposedException(S"copyFrom");
	return tidyOptCopyConfig(m_tdoc,copyFrom->m_tdoc)!=no;
}

int Document::ParseStream(System::IO::Stream* stm)
{
	CheckDisposed();
	StreamSource ss(stm);
	return tidyParseSource(m_tdoc,&ss);
}

int Document::SaveStream(System::IO::Stream* stm)
{
	CheckDisposed();
	StreamSink ss(stm);
	return tidySaveSink(m_tdoc,&ss);
}

int Document::SaveString(String*& output)
{
	CheckDisposed();
	TidyBuffer buf = {0};
	int ret = tidySaveBuffer(m_tdoc,&buf);
	if(ret<0) {
		output = String::Empty;
		return ret;
	}

	try {
		int charenc = tidyOptGetInt(m_tdoc,TidyOutCharEncoding);
		output = ConvertToString((char*)buf.bp,buf.size,charenc);
	} __finally {
		tidyBufFree(&buf);
	}

	return ret;
}

String* Document::get_Errors()
{
	CheckDisposed();
	return new String((char*)m_errbuf->bp);
}

} }