/////////////////////////////////////////////////////////////////////////////
//
// Html Tidy .NET Binding
// (C) Copyright 2003 VisionTech Limited. All rights reserved.
// http://www.visiontech.ltd.uk/
// bateman@acm.org
//
// VisionTech Limited makes no warranties, either express or implied,
// with respect to this source code and any accompanying materials.
//
// In no event shall VisionTech Limited or its suppliers be liable for
// any damages whatsoever (including, without limitation, damages for
// loss of business profits, business interruption, loss of business
// information, or other percuniary loss) arising out of the use or
// inability to use this software.
//
// This source code may be used for any purpose, including commercial
// applications, and may be modified or redistributed subject to the
// following conditions:
//
// a) This notice may not be removed or changed in any source distribution.
//
// b) Altered source versions must include a note to that effect,
//    and must not be misrepresented as the original.
//
// c) The origin of this software may not be misrepresented - you may
//    not claim to have written the original version. If you use this
//    source in a product, an acknowledgement in the documentation
//    would be appreciated, but is not required.
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#include <malloc.h>

__nogc class TidyMem
{
public:
	static void Init() {
		tidySetMallocCall(Malloc);
		tidySetReallocCall(Realloc);
		tidySetFreeCall(Free);
		tidySetPanicCall(Panic);
	}
	static void* Malloc(size_t len) {
		return malloc(len);
	}
	static void* Realloc(void* buf, size_t len) {
		return realloc(buf,len);
	}
	static void  Free(void* buf) {
		free(buf);
	}
	static void  Panic(ctmbstr mssg) {
		throw new OutOfMemoryException(mssg);
	}
};

__nogc class StreamSource : public TidyInputSource
{
public:
	StreamSource(System::IO::Stream* stm) : m_stm(stm) {
		memset(&m_buf,0,sizeof(m_buf));
		tidyInitSource(this,this,StreamGetByteFunc,StreamUngetByteFunc,StreamEOFFunc);
	}

	~StreamSource() {
		tidyBufFree(&m_buf);
	}

	static int StreamGetByteFunc(ulong sourceData) {
		StreamSource* ss = (StreamSource*)sourceData;
		int bv;
		if(ss->m_buf.size>0) {
			bv = tidyBufPopByte(&ss->m_buf);
		} else {
			bv = ss->m_stm->ReadByte();
		}
		return bv;
	}

	static void StreamUngetByteFunc(ulong sourceData, byte bt) {
		StreamSource* ss = (StreamSource*)sourceData;
		tidyBufPutByte(&ss->m_buf, bt);
	}

	static Bool StreamEOFFunc(ulong sourceData) {
		StreamSource* ss = (StreamSource*)sourceData;
		Bool isEOF = (ss->m_buf.size == 0)?yes:no;
		if(isEOF) {
			// Only way to find out if we are at the end of a stream is to try
			// reading - if we get -1 then we are, otherwise store the byte for the
			// next read
			int i = ss->m_stm->ReadByte();
			if(i != -1) {
				isEOF = no;
				tidyBufPutByte(&ss->m_buf, i);
			}
		}
		return isEOF;
	}

private:
	StreamRef	m_stm;
	TidyBuffer	m_buf;
};

__nogc class StreamSink : public TidyOutputSink
{
public:
	StreamSink(System::IO::Stream* stm) {
		tidyInitSink(this,new StreamRef(stm),StreamPutByte);
	}

	~StreamSink() {
		delete (StreamRef*)sinkData;
	}

	static void StreamPutByte(ulong sinkData, byte byteValue) {
		StreamRef* ref = (StreamRef*)sinkData;
		(*ref)->WriteByte(byteValue);
	}
};

__nogc class AnsiString
{
public:
	AnsiString(System::String* s) {
		m_p = (char*)Marshal::StringToHGlobalAnsi(s).ToPointer();
	}

	~AnsiString() {
		if(m_p!=NULL) {
#ifdef _DEBUG
			memset(m_p,0xcd,strlen(m_p));
#endif
			Marshal::FreeHGlobal(m_p);
		}
	}

	operator const char*() {
		return m_p;
	}

private:
	char*		m_p;
};

__nogc class UnicodeString
{
public:
	UnicodeString(System::String* s) {
		m_p = (wchar_t*)Marshal::StringToHGlobalUni(s).ToPointer();
	}

	~UnicodeString() {
		if(m_p!=NULL) {
#ifdef _DEBUG
			memset(m_p,0xcd,wcslen(m_p)*sizeof(wchar_t));
#endif
			Marshal::FreeHGlobal(m_p);
		}
	}

	operator const wchar_t*() {
		return m_p;
	}

private:
	wchar_t*		m_p;
};

/* character encodings
*/
#define CHARENC_RAW         0
#define CHARENC_ASCII       1
#define CHARENC_LATIN0      2
#define CHARENC_LATIN1      3
#define CHARENC_UTF8        4
#define CHARENC_ISO2022     5
#define CHARENC_MACROMAN    6
#define CHARENC_WIN1252     7
#define CHARENC_IBM858      8

#if SUPPORT_UTF16_ENCODINGS
#define CHARENC_UTF16LE     9
#define CHARENC_UTF16BE     10
#define CHARENC_UTF16       11
#endif

/* Note that Big5 and SHIFTJIS are not converted to ISO 10646 codepoints
** (i.e., to Unicode) before being recoded into UTF-8. This may be
** confusing: usually UTF-8 implies ISO10646 codepoints.
*/
#if SUPPORT_ASIAN_ENCODINGS
#if SUPPORT_UTF16_ENCODINGS
#define CHARENC_BIG5        12
#define CHARENC_SHIFTJIS    13
#else
#define CHARENC_BIG5        9
#define CHARENC_SHIFTJIS    10
#endif
#endif

String* ConvertToString(char* data,int len,int charenc)
{
	String* output = NULL;

	switch(charenc) {
		case CHARENC_UTF8:
			output = new String(data,0,len,System::Text::Encoding::UTF8);
			break;
		case CHARENC_UTF16BE:
			output = new String(data,0,len,System::Text::Encoding::BigEndianUnicode);
			break;
		case CHARENC_UTF16:
		case CHARENC_UTF16LE:
			output = new String(data,0,len,System::Text::Encoding::Unicode);
			break;
		case CHARENC_ASCII:
			output = new String(data,0,len,System::Text::Encoding::ASCII);
			break;
		default:
			output = new String(data,0,len,System::Text::Encoding::Default);
			break;
	}

	return output;
}

