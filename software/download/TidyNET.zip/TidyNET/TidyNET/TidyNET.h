/////////////////////////////////////////////////////////////////////////////
//
// Html Tidy .NET Binding
// (C) Copyright 2003 VisionTech Limited. All rights reserved.
// http://www.visiontech.ltd.uk/
// bateman@acm.org
//
// VisionTech Limited makes no warranties, either express or implied,
// with respect to this source code and any accompanying materials.
//
// In no event shall VisionTech Limited or its suppliers be liable for
// any damages whatsoever (including, without limitation, damages for
// loss of business profits, business interruption, loss of business
// information, or other percuniary loss) arising out of the use or
// inability to use this software.
//
// This source code may be used for any purpose, including commercial
// applications, and may be modified or redistributed subject to the
// following conditions:
//
// a) This notice may not be removed or changed in any source distribution.
//
// b) Altered source versions must include a note to that effect,
//    and must not be misrepresented as the original.
//
// c) The origin of this software may not be misrepresented - you may
//    not claim to have written the original version. If you use this
//    source in a product, an acknowledgement in the documentation
//    would be appreciated, but is not required.
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

using namespace System;
using namespace System::Runtime::InteropServices;
#include "Utils.h"

namespace VisionTech { namespace HtmlTidy {

#include "Enum.h" // import managed version of enums

public __gc class Document : public IDisposable
{
public:
	Document();
	~Document();

	void Dispose();

	// Library
	static String* LibraryReleaseDate() { return new String(tidyReleaseDate()); }

	// Options
	static OptionId OptionIdForName(String* name) { return (OptionId)tidyOptGetIdForName(AnsiString(name)); }
	String* GetOptionString(OptionId id);
	int GetOptionInt(OptionId id) { CheckDisposed(); return tidyOptGetInt(m_tdoc,(TidyOptionId)id); }
	AutoBool GetOptionAutoBool(OptionId id) { CheckDisposed(); return (AutoBool)tidyOptGetInt(m_tdoc,(TidyOptionId)id); }
	bool GetOptionBool(OptionId id) { CheckDisposed(); return tidyOptGetBool(m_tdoc,(TidyOptionId)id)!=no; }
	bool SetOption(OptionId id,bool value) { CheckDisposed(); return tidyOptSetBool(m_tdoc,(TidyOptionId)id,value ? yes : no) != no; }
	bool SetOption(OptionId id,AutoBool value) { CheckDisposed(); return tidyOptSetInt(m_tdoc,(TidyOptionId)id,(ulong)value) != no; }
	bool SetOption(OptionId id,int value) { CheckDisposed(); return tidyOptSetInt(m_tdoc,(TidyOptionId)id,(ulong)value) != no; }
	bool SetOption(OptionId id,String* value) { CheckDisposed(); return tidyOptSetValue(m_tdoc,(TidyOptionId)id,AnsiString(value)) != no; }
	bool ParseOption(String* option,String* value) { CheckDisposed(); return tidyOptParseValue(m_tdoc,AnsiString(option),AnsiString(value)) != no; }
	bool ResetOptionToDefault(OptionId id) { CheckDisposed(); return tidyOptResetToDefault(m_tdoc,(TidyOptionId)id)!=no; }
	bool ResetAllOptionsToDefault() { CheckDisposed(); return tidyOptResetAllToDefault(m_tdoc)!=no; }
	bool SnapshotOptions() { CheckDisposed(); return tidyOptSnapshot(m_tdoc)!=no; }
	bool ResetOptionsToSnapshot() { CheckDisposed(); return tidyOptResetToSnapshot(m_tdoc)!=no; }
	bool OptionsDiffThanDefault() { CheckDisposed(); return tidyOptDiffThanDefault(m_tdoc)!=no; }
	bool OptionsDiffThanSnapshot() { CheckDisposed(); return tidyOptDiffThanSnapshot(m_tdoc)!=no; }
	bool CopyOptions(Document* copyFrom);

	// Processing
	int SetCharEncoding(String* charenc) { CheckDisposed(); return tidySetCharEncoding(m_tdoc,AnsiString(charenc)); }
	int ParseString(String* value) { CheckDisposed(); return tidyParseString(m_tdoc,AnsiString(value)); }
	int ParseFile(String* filename) { CheckDisposed(); return tidyParseFile(m_tdoc,AnsiString(filename)); }
	int ParseStream(System::IO::Stream* stm);
	int CleanAndRepair() { CheckDisposed(); return tidyCleanAndRepair(m_tdoc); }
	int RunDiagnostics() { CheckDisposed(); return tidyRunDiagnostics(m_tdoc); }
	void ErrorSummary() { CheckDisposed(); tidyErrorSummary(m_tdoc); }
	void GeneralInfo() { CheckDisposed(); tidyGeneralInfo(m_tdoc); }

	// Saving results
	int SaveFile(String* filename) { CheckDisposed(); return tidySaveFile(m_tdoc,AnsiString(filename)); }
	int SaveString([Out]String*& output);
	int SaveStream(System::IO::Stream* stm);

	// Properties
	__property int get_Status() { CheckDisposed(); return tidyStatus(m_tdoc); }
	__property int get_DetectedHtmlVersion() { CheckDisposed(); return tidyDetectedHtmlVersion(m_tdoc); }
	__property bool get_DetectedXhtml() { CheckDisposed(); return tidyDetectedXhtml(m_tdoc)!=no; }
	__property bool get_DetectedGenericXml() { CheckDisposed(); return tidyDetectedGenericXml(m_tdoc)!=no; }
	__property int get_ErrorCount() { CheckDisposed(); return tidyErrorCount(m_tdoc); }
	__property int get_WarningCount() { CheckDisposed(); return tidyWarningCount(m_tdoc); }
	__property int get_AccessWarningCount() { CheckDisposed(); return tidyAccessWarningCount(m_tdoc); }
	__property int get_ConfigErrorCount() { CheckDisposed(); return tidyConfigErrorCount(m_tdoc); }
	__property String* get_Errors();

	// Get/Set config
	int LoadConfig(String* configFile) { CheckDisposed(); return tidyLoadConfig(m_tdoc,AnsiString(configFile)); }
	int LoadConfigEnc(String* configFile,String* charenc) { CheckDisposed(); return tidyLoadConfigEnc(m_tdoc,AnsiString(configFile),AnsiString(charenc)); }
	int SaveOptions(String* filename) { CheckDisposed(); return tidyOptSaveFile(m_tdoc,AnsiString(filename)); }

private:
	inline void CheckDisposed() {
		if(m_disposed) throw new ObjectDisposedException(S"Document has been disposed");
	}

private:
	bool			m_disposed;
	TidyDoc			m_tdoc;
	TidyBuffer*		m_errbuf;
}; // Document

} }