/* ====================================================================
 *
 * Copyright (c) 2002 VisionTech Limited.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        VisionTech Limited (http://www.visiontech.ltd.uk/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 */

// PreviewBar.cpp : Implementation of CPreviewBar
#include "stdafx.h"
#include "PreviewBar.h"


// CPreviewBar

LRESULT CPreviewBar::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/) {
	SetDlgItemInt(IDC_PAGE,m_current);
	SetDlgItemInt(IDC_PAGECOUNT,m_pagecount);
	SendDlgItemMessage(EM_LIMITTEXT,5);
	return 0;
}

LRESULT CPreviewBar::OnBnClickedPrint(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	__raise ClickPrint();
	return 0;
}

LRESULT CPreviewBar::OnBnClickedPagesetup(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	__raise ClickPageSetup();
	return 0;
}

LRESULT CPreviewBar::OnBnClickedFirst(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	if(m_current!=1) {
		SetCurrent(1);
		__raise PageChange(m_current);
	}
	return 0;
}

LRESULT CPreviewBar::OnBnClickedPrev(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	if(m_current>1) {
		SetCurrent(m_current-1);
		__raise PageChange(m_current);
	}
	return 0;
}

LRESULT CPreviewBar::OnBnClickedNext(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	if(m_current<m_pagecount) {
		SetCurrent(m_current+1);
		__raise PageChange(m_current);
	}
	return 0;
}

LRESULT CPreviewBar::OnBnClickedLast(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	if(m_current!=m_pagecount) {
		SetCurrent(m_pagecount);
		__raise PageChange(m_current);
	}
	return 0;
}

LRESULT CPreviewBar::OnBnClickedClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	__raise ClickClose();
	return 0;
}

STDMETHODIMP CPreviewBar::get_PageCount(SHORT* pVal)
{
	*pVal = m_pagecount;
	return S_OK;
}

STDMETHODIMP CPreviewBar::put_PageCount(SHORT newVal)
{
	if(newVal<=0) return Error(_T("PageCount must be >= 1"));
	m_pagecount = newVal;
	SetCurrent(1);
	SetDlgItemInt(IDC_PAGECOUNT,m_pagecount);
	return S_OK;
}

void CPreviewBar::SetCurrent(short page)
{
	m_current = page;
	SetDlgItemInt(IDC_PAGE,m_current);
}

STDMETHODIMP CPreviewBar::get_Page(short* pVal)
{
	*pVal = m_current;
	return S_OK;
}

STDMETHODIMP CPreviewBar::put_Page(short newVal)
{
	if(newVal<=0) return Error(_T("Page must be >= 1"));
	if(newVal>m_pagecount) return Error(_T("Page must be <= PageCount"));
	SetCurrent(newVal);
	return S_OK;
}

LRESULT CPreviewBar::OnEnChangePage(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	short page = (short)GetDlgItemInt(IDC_PAGE);
	if(page<1) {
		m_current = 1;
	} else if(page>m_pagecount) {
		m_current = m_pagecount;
	} else {
		m_current = page;
	}
	if(page!=m_current) SetDlgItemInt(IDC_PAGE,m_current);
	__raise PageChange(m_current);
	return 0;
}
