/* ====================================================================
 *
 * Copyright (c) 2002 VisionTech Limited.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        VisionTech Limited (http://www.visiontech.ltd.uk/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 */

// PreviewBar.h : Declaration of the CPreviewBar
#pragma once
#include "resource.h"       // main symbols
#include <atlctl.h>

// IPreviewBar
[
	object,
	uuid(D0C92F88-965E-47D5-A879-3B975EADC550),
	dual,
	helpstring("IPreviewBar Interface"),
	pointer_default(unique)
]
__interface IPreviewBar : public IDispatch
{
	[propget, id(1), helpstring("property PageCount")] HRESULT PageCount([out, retval] SHORT* pVal);
	[propput, id(1), helpstring("property PageCount")] HRESULT PageCount([in] SHORT newVal);
	[propget, id(2), helpstring("property Page")] HRESULT Page([out, retval] short* pVal);
	[propput, id(2), helpstring("property Page")] HRESULT Page([in] short newVal);
};


// _IPreviewBarEvents
[
	uuid("E7D1A64A-E8AA-463E-8E16-5F97283FAC72"),
	dispinterface,
	helpstring("_IPreviewBarEvents Interface")
]
__interface _IPreviewBarEvents
{
	[id(1), helpstring("method ClickPrint")] void ClickPrint(void);
	[id(2), helpstring("method ClickPageSetup")] void ClickPageSetup(void);
	[id(3), helpstring("method PageChange")] void PageChange(short nPage);
	[id(4), helpstring("method ClickClose")] void ClickClose(void);
};

// CPreviewBar
[
	coclass,
	threading("apartment"),
	vi_progid("IECtrl.PreviewBar"),
	progid("IECtrl.PreviewBar.1"),
	version(1.0),
	uuid("A4DF8582-161C-4851-8E96-E2843B3579F2"),
	helpstring("PreviewBar Class"),
	event_source("com"),
	support_error_info(IPreviewBar),
	registration_script("control.rgs"),
	implements_category("CATID_SafeForScripting")
]
class ATL_NO_VTABLE CPreviewBar : 
	public IPreviewBar,
	public IPersistStreamInitImpl<CPreviewBar>,
	public IOleControlImpl<CPreviewBar>,
	public IOleObjectImpl<CPreviewBar>,
	public IOleInPlaceActiveObjectImpl<CPreviewBar>,
	public IViewObjectExImpl<CPreviewBar>,
	public IOleInPlaceObjectWindowlessImpl<CPreviewBar>,
	public IObjectWithSiteImpl<CPreviewBar>,
	public CComCompositeControl<CPreviewBar>
{
public:

	CPreviewBar()
	{
		m_bWindowOnly = TRUE;
		CalcExtent(m_sizeExtent);
		m_pagecount = 1;
		m_current = 1;
	}

DECLARE_OLEMISC_STATUS(OLEMISC_RECOMPOSEONRESIZE | 
	OLEMISC_CANTLINKINSIDE | 
	OLEMISC_INSIDEOUT | 
	OLEMISC_ACTIVATEWHENVISIBLE | 
	OLEMISC_SETCLIENTSITEFIRST
)


BEGIN_PROP_MAP(CPreviewBar)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()


BEGIN_MSG_MAP(CPreviewBar)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_HANDLER(IDC_PRINT, BN_CLICKED, OnBnClickedPrint)
	COMMAND_HANDLER(IDC_PAGESETUP, BN_CLICKED, OnBnClickedPagesetup)
	COMMAND_HANDLER(IDC_FIRST, BN_CLICKED, OnBnClickedFirst)
	COMMAND_HANDLER(IDC_PREV, BN_CLICKED, OnBnClickedPrev)
	COMMAND_HANDLER(IDC_NEXT, BN_CLICKED, OnBnClickedNext)
	COMMAND_HANDLER(IDC_LAST, BN_CLICKED, OnBnClickedLast)
	COMMAND_HANDLER(IDC_CLOSE, BN_CLICKED, OnBnClickedClose)
	COMMAND_HANDLER(IDC_PAGE, EN_CHANGE, OnEnChangePage)
	CHAIN_MSG_MAP(CComCompositeControl<CPreviewBar>)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	__event __interface _IPreviewBarEvents;
// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IPreviewBar

	enum { IDD = IDD_PREVIEWBAR };

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

private:
	void SetCurrent(short page);
	short	m_pagecount;
	short	m_current;

public:
	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnBnClickedPrint(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedPagesetup(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedFirst(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedPrev(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedNext(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedLast(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	STDMETHOD(get_PageCount)(SHORT* pVal);
	STDMETHOD(put_PageCount)(SHORT newVal);
	STDMETHOD(get_Page)(short* pVal);
	STDMETHOD(put_Page)(short newVal);
	LRESULT OnEnChangePage(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
};

