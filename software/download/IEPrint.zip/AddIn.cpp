/* ====================================================================
 *
 * Copyright (c) 2002 VisionTech Limited.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        VisionTech Limited (http://www.visiontech.ltd.uk/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 */

// AddIn.cpp : Implementation of CAddIn

#include "stdafx.h"
#include "AddIn.h"

#define HR(s) { HRESULT _hr=s; if(FAILED(_hr)) return _hr; }

// CAddIn

STDMETHODIMP CAddIn::QueryStatus(
	const GUID *pguidCmdGroup,		// Pointer to command group
	ULONG cCmds,					// Number of commands in prgCmds array
	OLECMD *prgCmds,				// Array of commands
	OLECMDTEXT *pCmdText			// Pointer to name or status of command
	)
{
	// Just enable whatever commands it throws at us
	if(prgCmds==NULL) return E_POINTER;
	for(ULONG i=0; i<cCmds; i++) {
		prgCmds[i].cmdf = OLECMDF_SUPPORTED|OLECMDF_ENABLED;
	}
	return S_OK;
}

STDMETHODIMP CAddIn::Exec(
	const GUID *pguidCmdGroup, // Pointer to command group
	DWORD nCmdID, // Identifier of command to execute
	DWORD nCmdExecOpt, // Options for executing the command
	VARIANTARG *pvaIn, // Pointer to input arguments
	VARIANTARG *pvaOut // Pointer to command output
	)
{
	// The local resource containing the print template
	LPCTSTR path = _T("res://IEPrint.dll/template.htm");

	// Retrieve the IWebBrowser2 interface from the IObjectWithSite implementation
	CComQIPtr<IServiceProvider> spSP(m_spUnkSite);
	if(!spSP) return S_OK;
	CComPtr<IWebBrowser2> spWB2;
	CComVariant v(path);
	HR(spSP->QueryService(SID_SWebBrowserApp,&spWB2));

	// Get the control key status
	bool bCtrl = (GetAsyncKeyState(VK_CONTROL)&0x8000)!=0;

	// Call the print or print preview command with the resource print template.
	return spWB2->ExecWB(bCtrl ? OLECMDID_PRINTPREVIEW : OLECMDID_PRINT,OLECMDEXECOPT_PROMPTUSER,&v,NULL);
}