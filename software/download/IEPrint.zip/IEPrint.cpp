// IEPrint.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{7AEA607C-13B0-4A58-BD3B-F633A38344F7}", 
		 name = "IEPrint", 
		 helpstring = "Internet Explorer Enhanced Printing",
		 resource_name = "IDR_IEPRINT") ];
