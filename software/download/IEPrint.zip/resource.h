//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IEPrint.rc
//
#define IDS_PROJNAME                    100
#define IDR_IEPRINT                     101
#define IDD_PREVIEWBAR                  103
#define IDI_HOTICON                     200
#define IDI_ICON                        201
#define IDC_PRINT                       201
#define IDC_PAGESETUP                   202
#define IDC_FIRST                       203
#define IDC_PREV                        204
#define IDC_PAGE                        205
#define IDC_PAGECOUNT                   206
#define IDC_NEXT                        207
#define IDC_LAST                        208
#define IDC_CLOSE                       209

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
