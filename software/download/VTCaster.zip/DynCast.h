// DynCast.h : Declaration of the CDynCast

#ifndef __DYNCAST_H_
#define __DYNCAST_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDynCast
class ATL_NO_VTABLE CDynCast : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDynCast, &CLSID_DynCast>,
	public ISupportErrorInfo,
	public IDispatchImpl<IDynCast, &IID_IDynCast, &LIBID_VTCASTER>
{
public:
	CDynCast()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DYNCAST)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDynCast)
	COM_INTERFACE_ENTRY(IDynCast)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// Implementation
private:
	STDMETHOD(FindIIDByName)(LPUNKNOWN pUnk,BSTR sName,IID& iid,ITypeInfoPtr& pti2);

// IDynCast
public:
	STDMETHOD(castToInterface)(/*[in]*/ LPUNKNOWN srcObject,/*[in]*/ BSTR interfaceName,/*[out,retval]*/ LPDISPATCH* ppDisp);
};

#endif //__DYNCAST_H_
