// Wrapper.h : Declaration of the CDispatchWrapper

#ifndef __DISPATCHWRAPPER_H_
#define __DISPATCHWRAPPER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDispatchWrapper
class ATL_NO_VTABLE CDispatchWrapper : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IUnknown
{
public:
DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDispatchWrapper)
	COM_INTERFACE_ENTRY(IUnknown)
	COM_INTERFACE_ENTRY_AGGREGATE_BLIND(m_spUnk.p)
END_COM_MAP()

// Implementation
public:
	STDMETHODIMP WrapObject(LPUNKNOWN pObject, ITypeInfo *pTypeInfo)
	{
		if ((pObject == NULL) || (pTypeInfo == NULL))
			return E_POINTER;
		return CreateStdDispatch(this, pObject, pTypeInfo, &m_spUnk);
	}

private:
	CComPtr<IUnknown>	m_spUnk;
};

#endif //__DISPATCHWRAPPER_H_
