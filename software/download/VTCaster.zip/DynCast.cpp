// DynCast.cpp : Implementation of CDynCast
#include "stdafx.h"
#include "VTCaster.h"
#include "DynCast.h"
#include "Wrapper.h"

/////////////////////////////////////////////////////////////////////////////
// CDynCast

STDMETHODIMP CDynCast::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IDynCast
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::ATL::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CDynCast::castToInterface(LPUNKNOWN srcObject, BSTR interfaceName, LPDISPATCH* ppDisp)
{
	HRESULT hr;
	IID iid;
	ITypeInfoPtr pti;
	IUnknownPtr pUnk;
	*ppDisp= NULL;
	CComObject<CDispatchWrapper>* pWrap = NULL;

	if(srcObject==NULL || interfaceName==NULL)
		return E_POINTER;

	try
	{
		// Get the IID of the named interface and the ITypeInfo for the interface
		hr = FindIIDByName(srcObject,interfaceName,iid,pti);
		if(FAILED(hr)) return hr;

		// QI for the required IID
		hr = srcObject->QueryInterface(iid,(void**)&pUnk);
		if(FAILED(hr)) _com_raise_error(hr);

		hr = CComObject<CDispatchWrapper>::CreateInstance(&pWrap);
		if(FAILED(hr)) _com_raise_error(hr);
		hr = pWrap->WrapObject(pUnk,pti);
		if(FAILED(hr)) _com_raise_error(hr);
		hr = pWrap->QueryInterface(IID_IDispatch, (void **) ppDisp);
		if(FAILED(hr)) _com_raise_error(hr);
	}
	catch(_com_error e)
	{
		ATLTRACE("castToInterface: [%08x] %s\n",e.Error(),e.ErrorMessage());
		if(pWrap!=NULL) delete pWrap;
		return e.Error();
	}

	return S_OK;
}

STDMETHODIMP CDynCast::FindIIDByName(LPUNKNOWN pUnk,BSTR sName,IID& iid,ITypeInfoPtr& pti2)
{
	IProvideClassInfoPtr ppci;
	ITypeInfoPtr pti;
	TYPEATTR* pta = NULL;
	HRESULT hr;

	try
	{	
		// Query for IProvideClassInfo interface and get ITypeInfo for supplied object
		hr = pUnk->QueryInterface(&ppci);
		if(FAILED(hr)) _com_raise_error(hr);
		hr = ppci->GetClassInfo(&pti);
		if(FAILED(hr)) _com_raise_error(hr);

		// Get TYPEATTR pointer
		hr = pti->GetTypeAttr(&pta);
		if(FAILED(hr)) _com_raise_error(hr);

		// Just make sure we've got a coclass
		if(pta->typekind!=TKIND_COCLASS) {
			pti->ReleaseTypeAttr(pta);
			return Error(_T("srcObject doesn't seem to be a coclass"));
		}

		bool bFound = false;
		for(unsigned short j=0; !bFound && j<pta->cImplTypes; j++) {
			int flags;
			hr = pti->GetImplTypeFlags(j,&flags);
			// We're not interested in [source] interfaces
			if(FAILED(hr) || (flags & IMPLTYPEFLAG_FSOURCE)) continue;

			HREFTYPE ref;
			if(FAILED(pti->GetRefTypeOfImplType(j,&ref)) || FAILED(pti->GetRefTypeInfo(ref,&pti2)))
				continue;

			// okay, we've now got pti2 which points to an interface
			// that the coclass pti implements
			BSTR pszTypeInfoName;
			if(SUCCEEDED(pti2->GetDocumentation(MEMBERID_NIL,&pszTypeInfoName,NULL,NULL,NULL))) {
				if(!wcsicmp(pszTypeInfoName,sName)) {
					// Okay, this is the interface we want
					// Get the TYPEATTR so that we can find the IID
					TYPEATTR* pta2;
					hr = pti2->GetTypeAttr(&pta2);
					if(FAILED(hr)) {
						SysFreeString(pszTypeInfoName);
						_com_raise_error(hr);
					}
					iid = pta2->guid;
					bFound = true;
					pti2->ReleaseTypeAttr(pta2);
				}
				SysFreeString(pszTypeInfoName);
			}
			if(!bFound)
				pti2.Release();
		}
		// Release TYPEATTR
		pti->ReleaseTypeAttr(pta);
		pta = NULL;

		if(!bFound)
			return Error(_T("No matching interface name found"));
	}
	catch(_com_error e)
	{
		ATLTRACE("FindIID: [%08x] %s\n",e.Error(),e.ErrorMessage());
		if(pta!=NULL) pti->ReleaseTypeAttr(pta);
		return e.Error();
	}

	return S_OK;
}
