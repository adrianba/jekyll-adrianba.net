
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0280 */
/* at Mon Jun 25 22:11:50 2001
 */
/* Compiler settings for C:\WORK\VISIONTECH\UTILS\VTCaster\VTCaster.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __VTCaster_h__
#define __VTCaster_h__

/* Forward Declarations */ 

#ifndef __IDynCast_FWD_DEFINED__
#define __IDynCast_FWD_DEFINED__
typedef interface IDynCast IDynCast;
#endif 	/* __IDynCast_FWD_DEFINED__ */


#ifndef __DynCast_FWD_DEFINED__
#define __DynCast_FWD_DEFINED__

#ifdef __cplusplus
typedef class DynCast DynCast;
#else
typedef struct DynCast DynCast;
#endif /* __cplusplus */

#endif 	/* __DynCast_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IDynCast_INTERFACE_DEFINED__
#define __IDynCast_INTERFACE_DEFINED__

/* interface IDynCast */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDynCast;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8ACF652B-A389-46B5-A623-CE60E7C82110")
    IDynCast : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE castToInterface( 
            /* [in] */ LPUNKNOWN srcObject,
            /* [in] */ BSTR interfaceName,
            /* [retval][out] */ LPDISPATCH __RPC_FAR *ppDisp) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDynCastVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDynCast __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDynCast __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDynCast __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDynCast __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDynCast __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDynCast __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDynCast __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *castToInterface )( 
            IDynCast __RPC_FAR * This,
            /* [in] */ LPUNKNOWN srcObject,
            /* [in] */ BSTR interfaceName,
            /* [retval][out] */ LPDISPATCH __RPC_FAR *ppDisp);
        
        END_INTERFACE
    } IDynCastVtbl;

    interface IDynCast
    {
        CONST_VTBL struct IDynCastVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDynCast_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDynCast_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDynCast_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDynCast_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDynCast_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDynCast_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDynCast_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDynCast_castToInterface(This,srcObject,interfaceName,ppDisp)	\
    (This)->lpVtbl -> castToInterface(This,srcObject,interfaceName,ppDisp)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDynCast_castToInterface_Proxy( 
    IDynCast __RPC_FAR * This,
    /* [in] */ LPUNKNOWN srcObject,
    /* [in] */ BSTR interfaceName,
    /* [retval][out] */ LPDISPATCH __RPC_FAR *ppDisp);


void __RPC_STUB IDynCast_castToInterface_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDynCast_INTERFACE_DEFINED__ */



#ifndef __VTCASTER_LIBRARY_DEFINED__
#define __VTCASTER_LIBRARY_DEFINED__

/* library VTCASTER */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_VTCASTER;

EXTERN_C const CLSID CLSID_DynCast;

#ifdef __cplusplus

class DECLSPEC_UUID("3F0CAB13-13B4-436E-9B86-4F87AF31C491")
DynCast;
#endif
#endif /* __VTCASTER_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


