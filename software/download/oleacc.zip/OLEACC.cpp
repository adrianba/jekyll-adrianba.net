// OLEACC.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

#include "unknwn.h"

extern "C"  int    __declspec(dllexport) AccessibleObjectFromWindow(HWND
hwnd, DWORD dwId, REFIID riid, void **ppvObject) { return 0; }

extern "C"  int    __declspec(dllexport) CreateStdAccessibleObject(HWND
hwnd, LONG idObject, REFIID riid, void** ppvObject) {return 0; }

extern "C"  LRESULT      __declspec(dllexport) LresultFromObject(REFIID
riid, WPARAM wParam, LPUNKNOWN punk) { return 0; }
